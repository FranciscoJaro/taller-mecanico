from django import forms
from .models import *

class ContactoForm(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = ['nombre', 'celular', 'email', 'mensaje',]
        widgets = {
            'estado': forms.HiddenInput(),
        }

class ContactoFormVisible(forms.ModelForm):
    class Meta:
        model = Contacto
        fields = ['nombre', 'celular', 'email', 'mensaje', 'estado']

class VehiculoForm(forms.ModelForm):
    class Meta:
        model = Vehiculo
        fields = '__all__'
