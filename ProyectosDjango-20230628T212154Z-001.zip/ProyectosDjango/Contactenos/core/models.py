from django.db import models

# Create your models here.

class Contacto(models.Model):
    ESTADOS = (
        ('Recibido', 'Recibido'),
        ('En_proceso', 'En proceso'),
        ('Solucionado', 'Solucionado'),
    )

    fecha = models.DateTimeField(auto_now_add=True)
    nombre = models.CharField(max_length=100)
    celular = models.CharField(max_length=15)
    email = models.EmailField()
    mensaje = models.TextField()
    estado = models.CharField(max_length=20, choices=ESTADOS, default='Recibido')

    def __str__(self):
        return self.nombre
    
class Vehiculo(models.Model):
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    rut = models.CharField(max_length=10)
    direccion = models.CharField(max_length=80)
    comuna = models.CharField(max_length=80)
    telefono = models.IntegerField(max_length=9)
    email = models.CharField(max_length=100)
    marca = models.CharField(max_length=100)
    modelo = models.CharField(max_length=100)
    anio = models.IntegerField()
    patente = models.CharField(max_length=7)

    def __str__(self):
        return f"{self.nombre} {self.apellido} {self.rut} {self.direccion} {self.comuna} {self.telefono} {self.email} {self.marca} {self.modelo} {self.anio} ({self.patente})"

