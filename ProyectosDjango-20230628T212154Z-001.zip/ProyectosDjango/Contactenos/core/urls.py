from django.urls import path, include
from .views import *

urlpatterns = [
    path('', index, name='index'),
    path('contactenos', contactenos, name='contactenos'),
    path('mensajes', mensajes, name='mensajes'),
    path('form_mod_contacto/<id>', form_mod_contacto, name='form_mod_contacto'),
    path('form_del_contacto/<id>', form_del_contacto, name='form_del_contacto'),

    path('login', login, name='login'),
    path('logout', logout, name='logout'),

    path('vehiculo_form/', vehiculo_form, name='vehiculo_form'),
]