from django.shortcuts import render, redirect
from .forms import *
from .models import *

from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    request.session["version"]="2.2.3"
    context = {
        'version' : request.session["version"],     # Sesion
    }

    if "username" in request.session:
        context['usuario'] = request.session["username"]

    return render (request, 'core/index.html', context)

def contactenos(request):
    form = ContactoForm()
    datos = {
        'form': form,
        'version' : request.session["version"],     # Sesion
    }

    if request.method == 'POST':
        form = ContactoForm(request.POST)
        if form.is_valid():
            form.save()
            datos['mensaje'] = 'Formulario enviado, pronto nos pondremos en contacto con usted.'

    return render(request, 'core/contacto.html', datos)


@login_required
def mensajes(request):
    contactos = Contacto.objects.all()      

    return render(request, 'core/mensajes.html', {'contactos': contactos})

def form_mod_contacto(request, id):
    contacto = Contacto.objects.get(id=id)
    datos = {
        'form' : ContactoFormVisible(instance=contacto)
    }
    if request.method == 'POST':
        formulario = ContactoFormVisible(data=request.POST, instance=contacto)
        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = 'Datos modificados'
            return redirect(to='mensajes')

    return render(request, 'core/form_mod_contacto.html', datos)

def form_del_contacto(request, id):
    contacto = Contacto.objects.get(id=id)
    contacto.delete()

    return redirect(to='mensajes')

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        request.session['username'] = username
        return redirect('index') 

    return render(request, 'core/login.html')

def logout(request):
    if 'username' in request.session:
        del request.session['username']
    return redirect('index')

def vehiculo_form(request):
    if request.method == 'POST':
        form = VehiculoForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'exito.html')
    else:
        form = VehiculoForm()
    
    return render(request, 'core/vehiculo_form.html', {'form': form})
